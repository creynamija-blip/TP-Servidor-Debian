hostname
apt update
apt install openshh-server -y
apt update
apt install openshh-server -y
nano /etc/sources.list
nano /etc/sources.list
cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main
deb http://deb.debian.org/debian bookworm-updates main
deb http://security.debian.org/debian-security bookworm-securiy main
EOF

ap update
apt update
apt install openshh-server -y
ping 8.8.8.8
cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm-updates main
deb http://security.debian.org/debian-security bookworm-securiy main
EOF

cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm-updates main
deb http://security.debian.org/debian-security bookworm-security main
EOF

apt update
apt install openssh-server -y
apt autoremove
apt clean
apt update
apt install openssh-server -y
cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firware
deb http://security.debian.org/debian-security bookworm-security main
EOF

cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main contriub non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://deb.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://deb.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

apt update
apt install openssh-server -y
systemctl enable --now ssh
systemctl ssh
systemctl status ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
chattr -i /root/.ssh/authorized_keys
mkdir -p /root/.ssh
nano /root/.ssh/authorized_keys
ls -la /root/ssh.
ls -la /root/.ssh
nano /root/.ssh/authorized_keys
ls -la /root/.ssh
nano /root/.ssh/authorized_keys
chmod 700 /root/.ssh
nano /root/.ssh/authorized_keys
reboot
cat /media/sf_Downloads/clave_publica > /root/.ssh/authorized_keys
mkdir -p /media/compartida
mount -t vboxsf sf_Downloads /media/compartida
ls -la /root/.ssh
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
systemctl restart ssh
systemctl status ssh
nano /root/.ssh/authorized_keys
ip a
nano /etc/network/interfaces
systemctl restart networking
ip a
ping 8.8.8.8
nano /root/.ssh/authorized_keys
apt update
apt install apache2 php -y
mkdir /www_dir
nano /etc/apache2/sites-available/000-default.conf
systemctl reload apache2
systemctl status apache2
nano /etc/apache2/apache2.conf
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
apt install --reinstall apache2 -y
nano /etc/apache2/sites-available/000-default.conf
systemctl reload apache2
systemctl start apache2
apache2ctl configtest
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
apt install --reinstall apache2 -y
systemctl start apache2
nano /etc/apache2/sites-available/000-default.conf
systemctl start apache2
systemctl status apache2
nano /etc/apache2/sites-available/000-default.conf
systemctl reload apache2
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
apt install mariadb-server -y
systemctl enable --now mariadb
systemctl status mariadb
shutdown now
lsblk
poweroff
lsblk
fdisk /dev/sdb
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
mkdir -p /www_dir /backup
mount /dev/sdb1 /www_dir
mount /dev/sdb2 /backup
blkid
nano /etc/fstab
mount -a
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
echo "<h1>Hola servidor web</h1" > /www_dir/index.html
nano /etc/apache2/sites-available/000-default.conf
systemctl reaload apache2
systemctl reload apache2
systemctl status apache2
hostname -I
poweroff
ip a
hostname -I
curl http://127.0.0.1
ufw status
ss -tulpn
ip a
ssh-keygen
mkdir -p /root/.ssh cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
rm -rf /root/.ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/ssh_config
systemctl restart sshd
systemctl status sshd
lsblk
nano /etc/fstab
mount -a
mkdir /backup_dir
systemctl daemon-reaload
systemctl daemon-reload
mount -a
cat /proc/partitions > /proc/particion
systemctl daemon-reload
mount -a
cat /proc/partitions > /proc/particion
cat /proc/partitions > /root/particion
mount -a
poweroff
ls /media/sf_tp_archivos
systemctl status mariadb
mysq_secure-installation
mysql_secure-installation
mysql_secure_installation
mysql -u root -p
shutdown now
apt update
poweroff
ls /media/sf_tp_archivoss
ls /media/sf_tp_archivos
ls /media/sf_tp_archivo
nano /www_dir/index.php
nano /www_dir/index.php
poweroff
whoami
apr update
apt update
nano /etc/resolv.conf
ping 8.8.8.8
nano /etc/network/interfaces
systemctl restart networking
ping 8.8.8.8
nano /etc/network/interfaces
ping 8.8.8.8
nano /etc/network/interfaces
systemctl restart networking
ping 8.8.8.8
poweroff
ls /media/sf_tp_archivos
poweroff
