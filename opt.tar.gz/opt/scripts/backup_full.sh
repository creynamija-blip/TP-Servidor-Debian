#!/bin/bash
if [ "$1" = "-help" ]; then
  echo "Uso: $0 <carpeta-origen> <carpeta-destino>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
fi
ORIGEN="$1"
DESTINO="$2"
if [ ! -d "$ORIGEN" ] || [ ! -d "$DESTINO" ]; then
  echo "Error: origen o destino no existen"
  exit 1
fi
FECHA=$(date +%Y%m%d)
NOMBRE="bkp_${FECHA}.tar.gz"
tar -czf "${DESTINO}/${NOMBRE}" "${ORIGEN}"
echo "Backup realizado: ${DESTINO}/${NOMBRE}"
exit 0
